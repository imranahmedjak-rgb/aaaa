#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "[V60] Employer Navigation Interaction Reliability preflight"
sha256sum -c PAYLOAD-SHA256SUMS.txt
node --check payload/dist/public/assets/dgj-v51-employer.js >/dev/null
node --check payload/dist/public/assets/dgj-v51-recruitment.js >/dev/null
grep -Fq 'data-dgj60-hard-nav="overview"' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'window.__DGJ_V60_HARD_EMPLOYER_NAV__' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "location.assign(u.pathname+u.search+u.hash)" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "location.assign(employerTabHref(t))" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq '#dgj46-post-shell .dgj46-side{position:relative!important;z-index:2147483646!important' payload/dist/public/assets/dgj-v51-recruitment.css
grep -Fq '#dgj46-employer-root .dgj46-side nav button{position:relative!important;z-index:2147483001!important' payload/dist/public/assets/dgj-v51-recruitment.css
grep -Fq 'dgj-v51-employer.js?v=60.0.0' payload/dist/public/index.html
grep -Fq 'dgj-v51-recruitment.css?v=60.0.0' payload/dist/public/index.html
grep -Fq 'if(easyApplyBusy&&easyApplyJobKey===key)return' payload/dist/public/assets/dgj-v51-recruitment.js
for t in overview jobs applications analytics boosts billing plans profile; do grep -Fq "/employer?tab=$t" payload/dist/public/assets/dgj-v51-employer.js; done
echo "PASS: V60 real Post-a-Job routes, window-capture navigation, dashboard emergency routing, topmost hit targets and V58.1 Easy Apply singleton verified."
