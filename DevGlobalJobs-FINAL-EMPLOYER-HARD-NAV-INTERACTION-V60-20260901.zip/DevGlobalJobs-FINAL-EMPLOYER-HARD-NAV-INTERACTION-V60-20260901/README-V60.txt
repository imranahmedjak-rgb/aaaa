DEV GLOBAL JOBS V60
Employer Navigation Interaction Reliability

Run: bash deploy-v60-employer-hard-nav-safe.sh
Expected: SUCCESS: V60 EMPLOYER NAVIGATION INTERACTION FIX IS LIVE
