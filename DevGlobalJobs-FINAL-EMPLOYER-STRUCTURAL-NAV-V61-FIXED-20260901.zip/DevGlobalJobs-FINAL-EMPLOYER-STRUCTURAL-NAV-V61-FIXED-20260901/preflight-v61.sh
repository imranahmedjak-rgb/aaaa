#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "[V61] Employer Structural Navigation preflight"
sha256sum -c PAYLOAD-SHA256SUMS.txt
node --check payload/dist/public/assets/dgj-v51-employer.js >/dev/null
node --check payload/dist/public/assets/dgj-v51-recruitment.js >/dev/null
grep -Fq 'function promotePostSidebar(shell)' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "document.body.appendChild(side)" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'data-dgj61-native-nav="overview"' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'data-dgj61-dashboard-nav="${x[0]}"' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'window.__DGJ_V61_STRUCTURAL_EMPLOYER_NAV__' payload/dist/public/assets/dgj-v51-employer.js
! grep -Fq 'window.__DGJ_V60_HARD_EMPLOYER_NAV__' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'body.dgj46-employer-post-mode>#dgj61-post-side{position:fixed!important' payload/dist/public/assets/dgj-v51-recruitment.css
grep -Fq '#dgj46-post-shell.dgj61-sidebar-detached' payload/dist/public/assets/dgj-v51-recruitment.css
grep -Fq 'dgj-v51-employer.js?v=61.0.0' payload/dist/public/index.html
grep -Fq 'dgj-v51-recruitment.css?v=61.0.0' payload/dist/public/index.html
grep -Fq 'if(easyApplyBusy&&easyApplyJobKey===key)return' payload/dist/public/assets/dgj-v51-recruitment.js
for t in overview jobs applications analytics boosts billing plans profile; do grep -Fq "/employer?tab=$t" payload/dist/public/assets/dgj-v51-employer.js; done
echo "PASS: V61 detached Post Job sidebar, native href fallback, dashboard native routes and prior Easy Apply contracts verified."
