DEV GLOBAL JOBS V61
EMPLOYER STRUCTURAL NAVIGATION

V60 attempted to solve the non-clicking Employer sidebar with high z-index values and a window capture handler. The live browser still showed a visible sidebar whose actions did not respond.

V61 removes that dependency.

POST A JOB
The sidebar itself is moved outside the Post Job/React shell and attached directly to document.body. On desktop it is a top-level fixed navigation region. Its menu entries are ordinary same-origin links, so they work even if the application shell has a broken click handler or overlay.

EMPLOYER DASHBOARD
Dashboard tab entries use real href destinations. When live employer data is available, the page may enhance them to fast in-place tab switching; otherwise the browser follows the href normally.

PROTECTED
V57 Admin, V56 recruitment backend, database, pricing, payments, Premium Boost, Google Jobs, SEO, sitemap, PWA and service workers are not modified.
