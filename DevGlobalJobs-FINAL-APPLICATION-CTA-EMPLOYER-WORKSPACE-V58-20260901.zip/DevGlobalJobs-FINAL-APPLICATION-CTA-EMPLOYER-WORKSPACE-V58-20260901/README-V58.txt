DEV GLOBAL JOBS V58 - FINAL APPLICATION CTA + EMPLOYER WORKSPACE REPAIR
Date: 01 September 2026

PURPOSE
This package applies only the approved V58 UI/interaction repair on top of the successful V57 + V56-FIXED production baseline.

APPROVED RESULT
- Public job pages never expose Apply by Email, including during initial render.
- Employer Site + Easy Apply: Employer Site first, Easy Apply directly below.
- Easy Apply only: one full-width Easy Apply primary CTA before Share/Save.
- Easy Apply stays Dev Global Jobs royal blue. Green is limited to the verification tick/trust cue.
- Employer Workspace sidebar sections remain clickable after every rerender.
- Employer account email/company text stays contained inside the Hiring Account card.

SAFETY
The deploy script requires the exact successful V57/V56-FIXED baseline hashes before it mutates production. It creates a private rollback backup, installs only four reviewed frontend files, verifies origin delivery and backend health, and restores the backup automatically on a failed post-install contract.

NO DATABASE OR BACKEND MUTATION
No SQL is included. No backend module is replaced. No PM2 config is changed.

DEPLOY
Run deploy-v58-application-employer-safe.sh from the extracted package as root on the Dev Global Jobs VPS.
