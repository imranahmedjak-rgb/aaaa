DEV GLOBAL JOBS V59 - EMPLOYER INSTANT NAVIGATION + DASHBOARD PERFORMANCE
=====================================================================

Scope is intentionally limited to the Employer Workspace frontend plus the already-reviewed V58.1 Easy Apply singleton fix.

Fixes:
- Employer dashboard overview request starts as soon as the Employer JS is evaluated, before DOMContentLoaded.
- Dashboard navigation is interactive immediately; it is never disabled by the pending/skeleton state.
- Post-a-Job sidebar navigation uses a same-document Employer Workspace transition instead of a full-page reload.
- The post form stays safely mounted but hidden during the dashboard transition, allowing browser Back to restore it.
- Sidebar links/buttons are hardened against overlay/pointer-event conflicts and retain keyboard/focus support.
- Sidebar scrolling remains accessible with a wider, restrained desktop scrollbar.
- V58.1 Easy Apply singleton/race fix is included so the profile-quality note renders once.

Protected and unchanged:
- Recruitment backend and database schema
- V57 Admin Command Centre
- Employer backend and posting/payment logic
- Pricing, Premium Boost, payment providers
- Google Jobs, sitemap, SEO, service worker/PWA
- V56 80% profile gate, Profile CV and email segmentation

The deployment script accepts either the successful V58-FIXED frontend baseline or the V58.1 race-fix baseline, creates a private rollback backup, installs only four reviewed frontend files, validates exact origin bytes and rolls back on failure.
