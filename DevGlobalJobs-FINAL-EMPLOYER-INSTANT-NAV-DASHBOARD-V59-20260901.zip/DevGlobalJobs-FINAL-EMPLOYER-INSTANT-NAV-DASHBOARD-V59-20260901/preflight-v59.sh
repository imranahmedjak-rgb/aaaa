#!/usr/bin/env bash
set -Eeuo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PKG"
echo "[V59] Employer Instant Navigation + Dashboard Performance preflight"
sha256sum -c PAYLOAD-SHA256SUMS.txt
node --check payload/dist/public/assets/dgj-v51-employer.js >/dev/null
node --check payload/dist/public/assets/dgj-v51-recruitment.js >/dev/null
grep -Fq 'dgj-v51-employer.js?v=59.0.0' payload/dist/public/index.html
grep -Fq 'dgj-v51-recruitment.css?v=59.0.0' payload/dist/public/index.html
grep -Fq 'dgj-v51-recruitment.js?v=59.0.0' payload/dist/public/index.html
grep -Fq 'fetchpriority="high"' payload/dist/public/index.html
grep -Fq 'function beginEmployerPrefetch' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "portalPrefetchPromise=settled(api('/api/v46/employer/overview'))" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'function switchPostToEmployerTab' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'function bindPostNav' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'bindNav();const c=' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq '.dgj55-portal-pending .dgj46-side nav button{pointer-events:auto!important' payload/dist/public/assets/dgj-v51-recruitment.css
grep -Fq "if(easyApplyBusy&&easyApplyJobKey===key)return" payload/dist/public/assets/dgj-v51-recruitment.js
grep -Fq 'function cleanupEasyApplyMount' payload/dist/public/assets/dgj-v51-recruitment.js
echo "PASS: V59 fast dashboard, reliable sidebar and V58.1 singleton contracts verified."
