#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP=""
MUTATED=0
fail(){
  local msg="$*"
  echo
  echo "============================================================"
  echo "SAFE STOP: $msg"
  if [ "$MUTATED" = "1" ] && [ -n "$BACKUP" ] && [ -d "$BACKUP" ]; then
    echo "ROLLBACK: restoring exact pre-V59 frontend files..."
    cp -a "$BACKUP/index.html" "$APP/dist/public/index.html" || true
    cp -a "$BACKUP/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js" || true
    cp -a "$BACKUP/dgj-v51-recruitment.js" "$APP/dist/public/assets/dgj-v51-recruitment.js" || true
    cp -a "$BACKUP/dgj-v51-recruitment.css" "$APP/dist/public/assets/dgj-v51-recruitment.css" || true
    echo "ROLLBACK COMPLETE."
  fi
  echo "NO DATABASE, BACKEND, ADMIN, COMMERCIAL, PAYMENT, SEO OR PWA MUTATION WAS REQUESTED."
  echo "============================================================"
  exit 1
}
hash_is(){ local f="$1" h="$2"; [ -f "$f" ] && [ "$(sha256sum "$f"|awk '{print $1}')" = "$h" ]; }
hash_any(){ local f="$1"; shift; local a; [ -f "$f" ]||return 1; a="$(sha256sum "$f"|awk '{print $1}')"; for h in "$@"; do [ "$a" = "$h" ] && return 0; done; return 1; }

echo "============================================================"
echo "DEV GLOBAL JOBS V59"
echo "EMPLOYER INSTANT NAVIGATION + DASHBOARD PERFORMANCE"
echo "EARLY PREFETCH · ALWAYS-CLICKABLE NAV · SAME-DOCUMENT SIDEBAR"
echo "============================================================"
cd "$PKG"

echo "1/8 VERIFIED V58-FIXED / V58.1 BASELINE + HEALTH"
[ -d "$APP/dist/public/assets" ] || fail "Production asset directory missing."
CODE="$(curl -sS -o /tmp/dgj-v59-health-before.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = "200" ] || fail "Production API unhealthy before V59."
grep -Fq '"profileMinimum":80' /tmp/dgj-v59-health-before.json || fail "V56 profile-quality contract missing."
grep -Fq '"weeklyAudienceRule":"employer-precedence"' /tmp/dgj-v59-health-before.json || fail "V56 audience contract missing."
hash_any "$APP/dist/public/index.html" "8a09c5fac881e4a51e33f07cf40695586e49da278f70d78d7464e2345708a924" "b6d32f9cec0dfd1c9eb37b01923b2ca6c1f88dd3f94beae61c67155ea1099cc3" || fail "index.html is neither exact V58-FIXED nor V58.1 baseline."
hash_is "$APP/dist/public/assets/dgj-v51-employer.js" "5968be02c246501071a46b82d4cf82b10dc4424b6b7e000ff1f1276fc9200ae0" || fail "Employer JS differs from exact V58-FIXED baseline."
hash_any "$APP/dist/public/assets/dgj-v51-recruitment.js" "9ebea9db251f8618be7a576c47f4276982e830a6f9be9f6898b37c986eed39a0" "25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304" || fail "Recruitment JS is neither exact V58-FIXED nor V58.1 baseline."
hash_is "$APP/dist/public/assets/dgj-v51-recruitment.css" "e47d9ef23099629e056f814134a9142be7b7b7823c249b0369ac053623263958" || fail "Recruitment CSS differs from exact V58-FIXED baseline."
echo "PASS: supported production baseline healthy."

echo "2/8 PACKAGE PREFLIGHT"
bash "$PKG/preflight-v59.sh" || fail "V59 package preflight failed."
echo "PASS: V59 payload verified."

echo "3/8 PROTECTED ARCHITECTURE BEFORE MUTATION"
hash_is "$APP/dist/public/assets/dgj-v57-admin-enterprise.js" "8f463260c08757f95419ea461233315f18f0bbac590b2b287761e7b8e53cc0bf" || fail "Protected V57 Admin JS differs."
hash_is "$APP/dist/public/assets/dgj-v57-admin-enterprise.css" "ca06ccaa5ff05299f332597a47d672cc9cdeab8441f78344ccbca5c81bdb4c40" || fail "Protected V57 Admin CSS differs."
hash_is "$APP/dist/dgj-v51-recruitment.cjs" "1308d7d8c44dc91e48866b7747e64ecc4eef27ecdee57ad72868faaae912deba" || fail "Protected recruitment backend differs."
PROTECT_LIST=(
 "$APP/dist/public/assets/dgj-v57-admin-enterprise.js"
 "$APP/dist/public/assets/dgj-v57-admin-enterprise.css"
 "$APP/dist/dgj-v51-recruitment.cjs"
 "$APP/dist/dgj-v45-commercial.cjs"
 "$APP/dist/dgj-v46-employer.cjs"
 "$APP/dist/public/assets/dgj-v45-commercial.js"
 "$APP/dist/public/assets/dgj-v45-commercial.css"
 "$APP/dist/public/sw.js"
 "$APP/dist/public/service-worker.js"
)
PB="$PKG/.v59-protected-before.$$"; : > "$PB"
for f in "${PROTECT_LIST[@]}"; do [ -f "$f" ] && sha256sum "$f" >> "$PB"; done
echo "PASS: backend/Admin/commercial/PWA protected."

echo "4/8 PRIVATE ROLLBACK BACKUP"
BACKUP="/var/backups/devglobaljobs-v59-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp -a "$APP/dist/public/index.html" "$BACKUP/index.html"
cp -a "$APP/dist/public/assets/dgj-v51-employer.js" "$BACKUP/dgj-v51-employer.js"
cp -a "$APP/dist/public/assets/dgj-v51-recruitment.js" "$BACKUP/dgj-v51-recruitment.js"
cp -a "$APP/dist/public/assets/dgj-v51-recruitment.css" "$BACKUP/dgj-v51-recruitment.css"
echo "Backup: $BACKUP"

echo "5/8 ATOMIC FOUR-FILE INSTALL"
install -m 0644 "$PKG/payload/dist/public/index.html" "$APP/dist/public/index.html.v59-new"
install -m 0644 "$PKG/payload/dist/public/assets/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js.v59-new"
install -m 0644 "$PKG/payload/dist/public/assets/dgj-v51-recruitment.js" "$APP/dist/public/assets/dgj-v51-recruitment.js.v59-new"
install -m 0644 "$PKG/payload/dist/public/assets/dgj-v51-recruitment.css" "$APP/dist/public/assets/dgj-v51-recruitment.css.v59-new"
mv -f "$APP/dist/public/index.html.v59-new" "$APP/dist/public/index.html"
mv -f "$APP/dist/public/assets/dgj-v51-employer.js.v59-new" "$APP/dist/public/assets/dgj-v51-employer.js"
mv -f "$APP/dist/public/assets/dgj-v51-recruitment.js.v59-new" "$APP/dist/public/assets/dgj-v51-recruitment.js"
mv -f "$APP/dist/public/assets/dgj-v51-recruitment.css.v59-new" "$APP/dist/public/assets/dgj-v51-recruitment.css"
MUTATED=1
hash_is "$APP/dist/public/index.html" "04bab48c6e67302668a30428528f475f1332f906a5f4e90085a19375de54e9f2" || fail "Installed V59 index hash mismatch."
hash_is "$APP/dist/public/assets/dgj-v51-employer.js" "d5f861165338495b8cb4164e9b95b25ba80b7c3d0d7d568393d4102e681846eb" || fail "Installed V59 Employer JS hash mismatch."
hash_is "$APP/dist/public/assets/dgj-v51-recruitment.js" "25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304" || fail "Installed V59 Recruitment JS hash mismatch."
hash_is "$APP/dist/public/assets/dgj-v51-recruitment.css" "c746382ff6669a5501a6d98f910c306a7f0ef16bab352412d8da0757e7353a0b" || fail "Installed V59 Recruitment CSS hash mismatch."
echo "PASS: four reviewed frontend files installed."

echo "6/8 ORIGIN PERFORMANCE + NAVIGATION CONTRACT"
TMP="$(mktemp -d)"
curl -fsS --max-time 20 http://127.0.0.1:8080/ -o "$TMP/home" || fail "Origin homepage unreadable."
grep -Fq 'dgj-v51-employer.js?v=59.0.0' "$TMP/home" || fail "Origin Employer JS V59 wiring missing."
grep -Fq 'dgj-v51-recruitment.css?v=59.0.0' "$TMP/home" || fail "Origin Recruitment CSS V59 wiring missing."
grep -Fq 'dgj-v51-recruitment.js?v=59.0.0' "$TMP/home" || fail "Origin Recruitment JS V59 wiring missing."
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-employer.js?v=59.0.0' -o "$TMP/employer.js" || fail "Origin Employer JS unreadable."
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-recruitment.js?v=59.0.0' -o "$TMP/recruitment.js" || fail "Origin Recruitment JS unreadable."
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-recruitment.css?v=59.0.0' -o "$TMP/recruitment.css" || fail "Origin Recruitment CSS unreadable."
hash_is "$TMP/employer.js" "d5f861165338495b8cb4164e9b95b25ba80b7c3d0d7d568393d4102e681846eb" || fail "Origin Employer JS bytes mismatch."
hash_is "$TMP/recruitment.js" "25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304" || fail "Origin Recruitment JS bytes mismatch."
hash_is "$TMP/recruitment.css" "c746382ff6669a5501a6d98f910c306a7f0ef16bab352412d8da0757e7353a0b" || fail "Origin Recruitment CSS bytes mismatch."
grep -Fq 'function beginEmployerPrefetch' "$TMP/employer.js" || fail "Early Employer prefetch missing."
grep -Fq 'function switchPostToEmployerTab' "$TMP/employer.js" || fail "Same-document post navigation missing."
grep -Fq 'function bindPostNav' "$TMP/employer.js" || fail "Post sidebar click binding missing."
grep -Fq '.dgj55-portal-pending .dgj46-side nav button{pointer-events:auto!important' "$TMP/recruitment.css" || fail "Pending-nav interaction safeguard missing."
grep -Fq "if(easyApplyBusy&&easyApplyJobKey===key)return" "$TMP/recruitment.js" || fail "V58.1 Easy Apply singleton lock missing."
rm -rf "$TMP"
echo "PASS: origin serves exact V59 fast navigation assets."

echo "7/8 PROTECTED BYTES + BACKEND HEALTH"
while read -r expected file; do [ -f "$file" ] || continue; actual="$(sha256sum "$file"|awk '{print $1}')"; [ "$actual" = "$expected" ] || fail "Protected file changed unexpectedly: $file"; done < "$PB"
CODE2="$(curl -sS -o /tmp/dgj-v59-health-after.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE2" = "200" ] || fail "Backend health failed after V59."
cmp -s /tmp/dgj-v59-health-before.json /tmp/dgj-v59-health-after.json || fail "Backend config contract changed unexpectedly."
echo "PASS: protected architecture and backend unchanged."

echo "8/8 FINAL"
rm -f "$PB"
MUTATED=0
echo "============================================================"
echo "SUCCESS: V59 EMPLOYER INSTANT NAVIGATION IS LIVE"
echo "============================================================"
echo "✓ Employer overview starts fetching before DOMContentLoaded"
echo "✓ Sidebar remains clickable while live account data synchronises"
echo "✓ Post-a-Job sidebar opens Employer tabs without full-page reload"
echo "✓ Sidebar pointer, focus and scrolling safeguards are active"
echo "✓ Browser Back can restore the mounted Post-a-Job workspace"
echo "✓ V58.1 Easy Apply singleton/helper-note fix included"
echo "✓ V57 Admin, V56 backend, database, payments, SEO, Google Jobs and PWA unchanged"
echo "Rollback backup: $BACKUP"
echo "============================================================"
