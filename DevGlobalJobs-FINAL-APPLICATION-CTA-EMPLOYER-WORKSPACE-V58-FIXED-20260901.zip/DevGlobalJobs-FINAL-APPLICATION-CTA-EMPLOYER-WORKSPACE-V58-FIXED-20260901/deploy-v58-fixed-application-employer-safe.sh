#!/usr/bin/env bash
set -Eeuo pipefail

APP="/var/www/devglobaljobs"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP=""
MUTATED=0

fail(){
  local msg="$*"
  echo
  echo "============================================================"
  echo "SAFE STOP: $msg"
  if [ "$MUTATED" = "1" ] && [ -n "$BACKUP" ] && [ -d "$BACKUP" ]; then
    echo "ROLLBACK: restoring exact pre-V58 frontend files..."
    cp -a "$BACKUP/index.html" "$APP/dist/public/index.html" || true
    cp -a "$BACKUP/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js" || true
    cp -a "$BACKUP/dgj-v51-recruitment.js" "$APP/dist/public/assets/dgj-v51-recruitment.js" || true
    cp -a "$BACKUP/dgj-v51-recruitment.css" "$APP/dist/public/assets/dgj-v51-recruitment.css" || true
    echo "ROLLBACK COMPLETE."
  fi
  echo "NO DATABASE OR BACKEND MUTATION WAS REQUESTED BY V58."
  echo "============================================================"
  exit 1
}

hash_is(){
  local file="$1" expected="$2"
  [ -f "$file" ] || return 1
  [ "$(sha256sum "$file" | awk '{print $1}')" = "$expected" ]
}

echo "============================================================"
echo "DEV GLOBAL JOBS V58"
echo "APPLICATION CTA + EMPLOYER WORKSPACE REPAIR"
echo "ZERO-FLASH EMAIL REMOVAL · CTA ORDER · CLICKABLE NAV · EMAIL FIT"
echo "============================================================"

cd "$PKG"

echo "1/8 EXACT V57 + V56-FIXED BASELINE AND LIVE HEALTH"
[ -d "$APP/dist/public/assets" ] || fail "Production asset directory missing."
CODE="$(curl -sS -o /tmp/dgj-v58-health-before.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = "200" ] || fail "Production API is not healthy before V58."
grep -q '"profileMinimum":80' /tmp/dgj-v58-health-before.json || fail "V56 80% profile-quality contract is missing."
grep -q '"weeklyAudienceRule":"employer-precedence"' /tmp/dgj-v58-health-before.json || fail "V56 employer-precedence weekly audience contract is missing."

hash_is "$APP/dist/public/index.html" "7fe2c1b597fc53c3b264a405ba40b128688b722607add276ca29dcd4c0b478c5" || fail "public/index.html is not the exact successful V57 baseline."
hash_is "$APP/dist/public/assets/dgj-v51-employer.js" "ccb98c520e01e5d169d1dd25c97eb245897f78ecc75c16c9fedb7f8b0cb05323" || fail "Employer frontend is not the exact V56-FIXED baseline."
hash_is "$APP/dist/public/assets/dgj-v51-recruitment.js" "00f62b1ac36d7b3acd7aac5ad2b92bbcf6306c0bb923e047e178516f2d56cb76" || fail "Recruitment frontend JS is not the exact V56-FIXED baseline."
hash_is "$APP/dist/public/assets/dgj-v51-recruitment.css" "3a469af1f44d30050338510f2186cda9f2f4e2efaab511bf55af3d4d3725ec04" || fail "Recruitment frontend CSS is not the exact V56-FIXED baseline."
echo "PASS: exact V57/V56-FIXED production baseline healthy."

echo "2/8 V58 PACKAGE + STATIC REGRESSION PREFLIGHT"
bash "$PKG/preflight-v58.sh" || fail "V58 package preflight failed."
echo "PASS: V58 package verified."

echo "3/8 PROTECTED ARCHITECTURE BEFORE MUTATION"
hash_is "$APP/dist/public/assets/dgj-v57-admin-enterprise.js" "8f463260c08757f95419ea461233315f18f0bbac590b2b287761e7b8e53cc0bf" || fail "Protected V57 Admin JS differs from reviewed baseline."
hash_is "$APP/dist/public/assets/dgj-v57-admin-enterprise.css" "ca06ccaa5ff05299f332597a47d672cc9cdeab8441f78344ccbca5c81bdb4c40" || fail "Protected V57 Admin CSS differs from reviewed baseline."
hash_is "$APP/dist/dgj-v51-recruitment.cjs" "1308d7d8c44dc91e48866b7747e64ecc4eef27ecdee57ad72868faaae912deba" || fail "Protected V56 recruitment backend differs from reviewed baseline."

PROTECT_LIST=(
  "$APP/dist/public/assets/dgj-v57-admin-enterprise.js"
  "$APP/dist/public/assets/dgj-v57-admin-enterprise.css"
  "$APP/dist/dgj-v51-recruitment.cjs"
  "$APP/dist/dgj-v45-commercial.cjs"
  "$APP/dist/dgj-v46-employer.cjs"
  "$APP/dist/public/assets/dgj-v45-commercial.js"
  "$APP/dist/public/assets/dgj-v45-commercial.css"
  "$APP/dist/public/sw.js"
  "$APP/dist/public/service-worker.js"
)
PROTECTED_BEFORE="$PKG/.v58-protected-before.$$"
: > "$PROTECTED_BEFORE"
for f in "${PROTECT_LIST[@]}"; do [ -f "$f" ] && sha256sum "$f" >> "$PROTECTED_BEFORE"; done
echo "PASS: backend, V57 Admin, commercial and service-worker files protected."

echo "4/8 PRIVATE ROLLBACK BACKUP"
BACKUP="/var/backups/devglobaljobs-v58-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp -a "$APP/dist/public/index.html" "$BACKUP/index.html"
cp -a "$APP/dist/public/assets/dgj-v51-employer.js" "$BACKUP/dgj-v51-employer.js"
cp -a "$APP/dist/public/assets/dgj-v51-recruitment.js" "$BACKUP/dgj-v51-recruitment.js"
cp -a "$APP/dist/public/assets/dgj-v51-recruitment.css" "$BACKUP/dgj-v51-recruitment.css"
echo "Backup: $BACKUP"

echo "5/8 ATOMIC V58 FRONTEND INSTALL"
install -m 0644 "$PKG/payload/dist/public/index.html" "$APP/dist/public/index.html.v58-new"
install -m 0644 "$PKG/payload/dist/public/assets/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js.v58-new"
install -m 0644 "$PKG/payload/dist/public/assets/dgj-v51-recruitment.js" "$APP/dist/public/assets/dgj-v51-recruitment.js.v58-new"
install -m 0644 "$PKG/payload/dist/public/assets/dgj-v51-recruitment.css" "$APP/dist/public/assets/dgj-v51-recruitment.css.v58-new"
mv -f "$APP/dist/public/index.html.v58-new" "$APP/dist/public/index.html"
mv -f "$APP/dist/public/assets/dgj-v51-employer.js.v58-new" "$APP/dist/public/assets/dgj-v51-employer.js"
mv -f "$APP/dist/public/assets/dgj-v51-recruitment.js.v58-new" "$APP/dist/public/assets/dgj-v51-recruitment.js"
mv -f "$APP/dist/public/assets/dgj-v51-recruitment.css.v58-new" "$APP/dist/public/assets/dgj-v51-recruitment.css"
MUTATED=1

hash_is "$APP/dist/public/index.html" "8a09c5fac881e4a51e33f07cf40695586e49da278f70d78d7464e2345708a924" || fail "Installed V58 index hash mismatch."
hash_is "$APP/dist/public/assets/dgj-v51-employer.js" "5968be02c246501071a46b82d4cf82b10dc4424b6b7e000ff1f1276fc9200ae0" || fail "Installed V58 Employer JS hash mismatch."
hash_is "$APP/dist/public/assets/dgj-v51-recruitment.js" "9ebea9db251f8618be7a576c47f4276982e830a6f9be9f6898b37c986eed39a0" || fail "Installed V58 Recruitment JS hash mismatch."
hash_is "$APP/dist/public/assets/dgj-v51-recruitment.css" "e47d9ef23099629e056f814134a9142be7b7b7823c249b0369ac053623263958" || fail "Installed V58 Recruitment CSS hash mismatch."
echo "PASS: only four reviewed V58 frontend files installed."

echo "6/8 ORIGIN PRESENTATION CONTRACT"
TMP="$(mktemp -d)"
curl -fsS --max-time 20 http://127.0.0.1:8080/ -o "$TMP/home" || fail "Origin homepage could not be read after V58 install."
grep -Fq 'dgj-v58-public-apply-zero-flash' "$TMP/home" || fail "Origin index is not serving the V58 zero-flash guard."
grep -Fq 'dgj-v51-employer.js?v=58.0.0' "$TMP/home" || fail "Origin index is not serving V58 Employer JS wiring."
grep -Fq 'dgj-v51-recruitment.js?v=58.0.0' "$TMP/home" || fail "Origin index is not serving V58 Recruitment JS wiring."
grep -Fq 'dgj-v51-recruitment.css?v=58.0.0' "$TMP/home" || fail "Origin index is not serving V58 Recruitment CSS wiring."

curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-employer.js?v=58.0.0' -o "$TMP/employer.js" || fail "Origin V58 Employer JS could not be read."
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-recruitment.js?v=58.0.0' -o "$TMP/recruitment.js" || fail "Origin V58 Recruitment JS could not be read."
curl -fsS --max-time 20 'http://127.0.0.1:8080/assets/dgj-v51-recruitment.css?v=58.0.0' -o "$TMP/recruitment.css" || fail "Origin V58 Recruitment CSS could not be read."

hash_is "$TMP/employer.js" "5968be02c246501071a46b82d4cf82b10dc4424b6b7e000ff1f1276fc9200ae0" || fail "Origin V58 Employer JS bytes mismatch."
hash_is "$TMP/recruitment.js" "9ebea9db251f8618be7a576c47f4276982e830a6f9be9f6898b37c986eed39a0" || fail "Origin V58 Recruitment JS bytes mismatch."
hash_is "$TMP/recruitment.css" "e47d9ef23099629e056f814134a9142be7b7b7823c249b0369ac053623263958" || fail "Origin V58 Recruitment CSS bytes mismatch."
rm -rf "$TMP"

echo "PASS: origin serves V58 CTA/nav/account-card assets and exact reviewed bytes."

echo "7/8 PROTECTED BYTE + BACKEND HEALTH CHECK"
while read -r expected file; do
  [ -f "$file" ] || continue
  actual="$(sha256sum "$file" | awk '{print $1}')"
  [ "$actual" = "$expected" ] || fail "Protected file changed unexpectedly: $file"
done < "$PROTECTED_BEFORE"
CODE2="$(curl -sS -o /tmp/dgj-v58-health-after.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE2" = "200" ] || fail "Backend health failed after frontend-only V58 install."
cmp -s /tmp/dgj-v58-health-before.json /tmp/dgj-v58-health-after.json || fail "Backend config contract changed during frontend-only V58 install."
echo "PASS: V57 Admin, V56 backend, commercial and backend health unchanged."

echo "8/8 FINAL"
rm -f "$PROTECTED_BEFORE"
MUTATED=0

echo "============================================================"
echo "SUCCESS: V58-FIXED APPLICATION + EMPLOYER WORKSPACE REPAIR IS LIVE"
echo "============================================================"
echo "✓ Apply by Email suppressed before paint and never retained as a public CTA"
echo "✓ Employer Site remains first when available"
echo "✓ Easy Apply appears directly below Employer Site, or alone when it is the only native application path"
echo "✓ Easy Apply remains royal blue; green is limited to the verification tick"
echo "✓ Share and Save remain secondary actions below application CTAs"
echo "✓ Employer Workspace sidebar uses persistent delegated navigation across rerenders"
echo "✓ Employer email/company text stays inside the Hiring Account card"
echo "✓ V57 Admin Command Centre unchanged"
echo "✓ V56 backend/profile/CV/email segmentation unchanged"
echo "✓ Payments, SEO, Google Jobs, PWA and database unchanged"
echo "Rollback backup: $BACKUP"
echo "============================================================"
