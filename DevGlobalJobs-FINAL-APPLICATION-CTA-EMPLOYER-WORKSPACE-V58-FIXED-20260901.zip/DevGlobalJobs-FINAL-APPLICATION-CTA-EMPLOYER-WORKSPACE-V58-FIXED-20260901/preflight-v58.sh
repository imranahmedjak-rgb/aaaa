#!/usr/bin/env bash
set -Eeuo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PKG"

echo "[V58] Application CTA + Employer Workspace Repair 58.0.0 preflight"
sha256sum -c PAYLOAD-SHA256SUMS.txt
node --check payload/dist/public/assets/dgj-v51-employer.js >/dev/null
node --check payload/dist/public/assets/dgj-v51-recruitment.js >/dev/null

grep -q 'dgj-v58-public-apply-zero-flash' payload/dist/public/index.html
grep -q 'dgj-v51-employer.js?v=58.0.0' payload/dist/public/index.html
grep -q 'dgj-v51-recruitment.js?v=58.0.0' payload/dist/public/index.html
grep -q 'dgj-v51-recruitment.css?v=58.0.0' payload/dist/public/index.html

grep -q "function placeEasyApply" payload/dist/public/assets/dgj-v51-recruitment.js
grep -q "dgj58-employer-site-control" payload/dist/public/assets/dgj-v51-recruitment.js
grep -q 'dgj58-public-email-apply' payload/dist/public/assets/dgj-v51-recruitment.js
grep -q "EMPLOYER_TABS" payload/dist/public/assets/dgj-v51-employer.js
grep -q "dgj58NavBound" payload/dist/public/assets/dgj-v51-employer.js
grep -q "dgj58-account-email" payload/dist/public/assets/dgj-v51-employer.js
grep -q "#dgj46-employer-root:not(.dgj55-portal-pending)" payload/dist/public/assets/dgj-v51-recruitment.css

grep -q 'dgj-v57-admin-enterprise.css?v=57.0.0' payload/dist/public/index.html
grep -q 'dgj-v57-admin-enterprise.js?v=57.0.0' payload/dist/public/index.html

echo "PASS: V58 CTA hierarchy, zero-flash email suppression, employer navigation and account-card containment verified."
